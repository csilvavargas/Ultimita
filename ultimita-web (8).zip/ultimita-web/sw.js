const C='ult-v2',A=['./','index.html','manifest.webmanifest','icon-192.png','icon-512.png','data.json','inter-400.woff','inter-500.woff','inter-600.woff','barlow-condensed-600.woff','barlow-condensed-700.woff'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(A)));self.skipWaiting()});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))));self.clients.claim()});
self.addEventListener('fetch',e=>{
 const u=new URL(e.request.url);
 if(e.request.method!=='GET'||u.origin!==location.origin)return;
 const clave=new Request(u.origin+u.pathname);
 if(u.pathname.endsWith('data.json')||e.request.mode==='navigate'){
  e.respondWith(fetch(e.request).then(r=>{const cp=r.clone();caches.open(C).then(c=>c.put(clave,cp));return r}).catch(()=>caches.match(clave).then(m=>m||caches.match('index.html'))));
  return}
 e.respondWith(caches.match(e.request,{ignoreSearch:true}).then(m=>m||fetch(e.request).then(r=>{const cp=r.clone();caches.open(C).then(c=>c.put(e.request,cp));return r})))});
