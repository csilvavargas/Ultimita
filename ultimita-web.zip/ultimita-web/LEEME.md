# La Ultimita, app web para iPhone y Android

Funciona en el navegador y se instala en la pantalla de inicio. No necesita Claude, ni App Store, ni Google Play.

## A. Publicarla (una sola vez, unos 10 minutos; es más fácil desde un computador)
1. Crea una cuenta gratis en github.com.
2. Toca "+" > New repository. Nombre: `ultimita`. Marca Public. Create repository.
3. Toca "uploading an existing file" y suelta los 8 archivos de esta carpeta (los archivos, no la carpeta). Commit changes.
4. Entra a Settings > Pages. En Source elige "Deploy from a branch", rama `main`, carpeta `/ (root)`, y Save.
5. En 1 o 2 minutos aparece la dirección `https://TU-USUARIO.github.io/ultimita/`. Ese es el link para los jugadores.

Instalarla en el celular:
- iPhone: abrir el link en Safari > Compartir > Agregar a pantalla de inicio.
- Android: abrir el link en Chrome > menú de tres puntos > Instalar app (o Agregar a pantalla principal).

## B. Modo editor (solo tú)
1. Abre `https://TU-USUARIO.github.io/ultimita/#editor` una vez desde tu teléfono. Aparece el botón "Editar" arriba.
2. Crea un token en GitHub: tu foto > Settings > Developer settings > Personal access tokens > Fine-grained tokens > Generate new token. En Repository access elige "Only select repositories" y `ultimita`. En Repository permissions pon Contents: Read and write. Genera el token y cópialo.
3. En la app: Editar > Configurar GitHub. Escribe `TU-USUARIO/ultimita` y pega el token.
4. Edita titulares, rival, asistencia y jugadas, y toca "Publicar cambios". Los jugadores ven el cambio en 1 o 2 minutos, al abrir o recargar la app.

Sin token: toca "Exportar archivo" y reemplaza `data.json` en el repositorio (Add file > Upload files).

## C. Tabla, fixture y datos del partido
Los carga Claude. Pásale los datos y el `data.json` actual, y te devuelve uno actualizado para subir al repositorio. Si no le das el actual, se pierden los cambios que hayas publicado desde la app.

## Avisos
- El repositorio es público: cualquiera con el link puede ver nombres, asistencia y jugadas. Un repositorio privado con Pages requiere un plan de pago de GitHub (verifica las condiciones vigentes).
- El token da permiso de escritura sobre ese repositorio. Queda guardado solo en tu teléfono. No lo compartas; si lo pierdes, bórralo en GitHub.
- Los nombres de los menús de GitHub cambian de vez en cuando.
- No se probó en teléfonos reales: la publicación a GitHub, la instalación en pantalla de inicio y el modo sin conexión.
